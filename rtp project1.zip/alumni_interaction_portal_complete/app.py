from flask import Flask, render_template, request, abort

app = Flask(__name__)

ALUMNI = [
    {
        "id": 1,
        "name": "Aarav Kumar",
        "email": "aarav.kumar@example.com",
        "graduation": "B.Tech CSE, 2022",
        "company": "TechNova Solutions",
        "role": "Software Engineer",
        "location": "Hyderabad",
        "skills": "Python, Flask, SQL, AWS",
        "experience": "3 years",
        "bio": "Software engineer interested in backend development, cloud technologies and mentoring students.",
        "achievements": "Built scalable web applications and mentored junior developers."
    },
    {
        "id": 2,
        "name": "Priya Sharma",
        "email": "priya.sharma@example.com",
        "graduation": "B.Tech CSE, 2021",
        "company": "Deloitte",
        "role": "Business Technology Analyst",
        "location": "Bengaluru",
        "skills": "SQL, Data Analytics, Power BI",
        "experience": "4 years",
        "bio": "Technology professional who enjoys helping students understand careers in IT consulting and analytics.",
        "achievements": "Worked on enterprise analytics and business technology projects."
    },
    {
        "id": 3,
        "name": "Rahul Reddy",
        "email": "rahul.reddy@example.com",
        "graduation": "B.Tech CSE, 2020",
        "company": "Infosys",
        "role": "DevOps Engineer",
        "location": "Hyderabad",
        "skills": "AWS, Linux, Docker, Jenkins",
        "experience": "5 years",
        "bio": "Cloud and DevOps professional offering guidance on cloud careers, projects and interview preparation.",
        "achievements": "Automated deployment workflows and supported cloud infrastructure projects."
    },
    {
        "id": 4,
        "name": "Sneha Patel",
        "email": "sneha.patel@example.com",
        "graduation": "B.Tech IT, 2023",
        "company": "Amazon",
        "role": "Data Analyst",
        "location": "Chennai",
        "skills": "Python, Pandas, SQL, Tableau",
        "experience": "2 years",
        "bio": "Data analyst focused on data-driven decision making and career mentoring.",
        "achievements": "Created dashboards and analytics solutions for business teams."
    },
    {
        "id": 5,
        "name": "Vikram Singh",
        "email": "vikram.singh@example.com",
        "graduation": "B.Tech CSE, 2019",
        "company": "Microsoft",
        "role": "Cloud Engineer",
        "location": "Pune",
        "skills": "Azure, Python, Kubernetes, Terraform",
        "experience": "6 years",
        "bio": "Cloud engineer interested in infrastructure, automation and helping students prepare for cloud roles.",
        "achievements": "Worked on cloud migration and infrastructure automation projects."
    }
]

@app.route("/")
def home():
    return render_template("index.html", featured=ALUMNI[:3])

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/references")
def references():
    return render_template("references.html")

@app.route("/alumni")
def alumni_directory():
    query = request.args.get("q", "").strip().lower()
    if query:
        results = [
            person for person in ALUMNI
            if query in person["name"].lower()
            or query in person["company"].lower()
            or query in person["role"].lower()
            or query in person["location"].lower()
            or query in person["skills"].lower()
        ]
    else:
        results = ALUMNI
    return render_template("alumni.html", alumni=results, query=request.args.get("q", ""))

@app.route("/alumni/<int:alumni_id>")
def alumni_details(alumni_id):
    person = next((p for p in ALUMNI if p["id"] == alumni_id), None)
    if not person:
        abort(404)
    return render_template("alumni_detail.html", person=person)

@app.route("/connect/<int:alumni_id>", methods=["GET", "POST"])
def connect(alumni_id):
    person = next((p for p in ALUMNI if p["id"] == alumni_id), None)
    if not person:
        abort(404)
    submitted = request.method == "POST"
    return render_template("connect.html", person=person, submitted=submitted)

if __name__ == "__main__":
    app.run(debug=True)
