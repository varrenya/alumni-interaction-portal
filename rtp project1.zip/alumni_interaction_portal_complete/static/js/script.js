document.addEventListener("DOMContentLoaded", () => {
  console.log("Alumni Interaction Portal loaded successfully.");
});
